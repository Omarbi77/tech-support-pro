<?php
// Print recent tickets and their stored category FK or joined category name for diagnosis
include 'includes/db.php';
$dbname = isset($dbname) ? $dbname : 'tech_support_db';

// Detect tickets FK column
$tickets_fk = null;
$tickets_cols_sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'tickets' ORDER BY ORDINAL_POSITION";
if ($stmt_tc = $conn->prepare($tickets_cols_sql)) {
    $stmt_tc->bind_param("s", $dbname);
    $stmt_tc->execute();
    $res_tc = $stmt_tc->get_result();
    $preferred = ['category_id','categoryid','category','cat_id','catid'];
    while ($c = $res_tc->fetch_assoc()) {
        $colname = $c['COLUMN_NAME'];
        foreach ($preferred as $p) {
            if (strcasecmp($colname, $p) === 0) {
                $tickets_fk = $colname;
                break 2;
            }
        }
        if ($tickets_fk === null && (stripos($colname, 'category') !== false || stripos($colname, 'cat') !== false)) {
            $tickets_fk = $colname;
        }
    }
    $stmt_tc->close();
}

// Detect categories PK
$categories_pk = 'id';
$pk_sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'categories' AND COLUMN_KEY = 'PRI' LIMIT 1";
if ($stmt_pk = $conn->prepare($pk_sql)) {
    $stmt_pk->bind_param("s", $dbname);
    $stmt_pk->execute();
    $res_pk = $stmt_pk->get_result();
    if ($rowpk = $res_pk->fetch_assoc()) {
        $categories_pk = $rowpk['COLUMN_NAME'];
    }
    $stmt_pk->close();
}

// Try to join to categories if possible
$join_clause = '';
$category_select = '';
if ($tickets_fk && $categories_pk) {
    // try to detect a display column for categories
    $display_col = null;
    $col_check_sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'categories'";
    if ($stmt_col = $conn->prepare($col_check_sql)) {
        $stmt_col->bind_param('s', $dbname);
        $stmt_col->execute();
        $res = $stmt_col->get_result();
        while ($col = $res->fetch_assoc()) {
            if (in_array($col['COLUMN_NAME'], ['category_name','name'])) {
                $display_col = $col['COLUMN_NAME'];
                break;
            }
        }
        $stmt_col->close();
    }
    if ($display_col) {
        $category_select = "categories.`$display_col` AS category_name";
        $join_clause = "LEFT JOIN categories ON tickets.`$tickets_fk` = categories.`$categories_pk`";
    } else {
        $category_select = "tickets.`$tickets_fk` AS category_value";
    }
} else {
    $category_select = $tickets_fk ? "tickets.`$tickets_fk` AS category_value" : "NULL AS category_value";
}

$query = "SELECT tickets.id, tickets.user_id, $category_select, tickets.description, tickets.status, tickets.created_at FROM tickets " . $join_clause . " ORDER BY tickets.created_at DESC LIMIT 50";

if ($stmt = $conn->prepare($query)) {
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 0) {
        echo "No tickets found.\n";
    } else {
        while ($r = $res->fetch_assoc()) {
            echo "ticket_id=" . $r['id'] . " | user_id=" . $r['user_id'] . " | ";
            if (isset($r['category_name'])) {
                echo "category_name=" . $r['category_name'];
            } elseif (isset($r['category_value'])) {
                echo "category_value=" . $r['category_value'];
            } elseif (isset($r['category_id'])) {
                echo "category_id=" . $r['category_id'];
            } else {
                echo "category=(none)";
            }
            echo " | description=" . substr($r['description'],0,60) . " | status=" . $r['status'] . "\n";
        }
    }
} else {
    echo "Prepare failed: " . $conn->error . "\n";
}

$conn->close();
?>