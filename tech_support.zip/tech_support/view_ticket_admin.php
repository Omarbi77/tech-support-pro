<?php
session_start();
include 'includes/header.html';
include 'includes/db.php';
require_once 'includes/auth.php';
// Ensure the user is logged in as an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Validate ticket ID
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $ticket_id = intval($_GET['id']);

    // Fetch ticket details with category name
    $ticket_query = "SELECT tickets.*, users.name AS user_name, categories.category_name AS category
                     FROM tickets
                     JOIN users ON tickets.user_id = users.id
                     JOIN categories ON tickets.category_id = categories.id
                     WHERE tickets.id = ?";
    $stmt = $conn->prepare($ticket_query);
    $stmt->bind_param("i", $ticket_id);
    $stmt->execute();
    $ticket_result = $stmt->get_result();

    if ($ticket_result->num_rows === 0) {
        header("Location: admin.php?error=" . urlencode("Ticket not found."));
        exit();
    }

    $ticket = $ticket_result->fetch_assoc();

    // Fetch replies
    $replies_query = "SELECT sender, message, created_at FROM ticket_replies WHERE ticket_id = ? ORDER BY created_at ASC";
    $stmt = $conn->prepare($replies_query);
    $stmt->bind_param("i", $ticket_id);
    $stmt->execute();
    $replies_result = $stmt->get_result();

    // Handle status updates
    if (isset($_POST['update_ticket_status'])) {
        $new_status = htmlspecialchars($_POST['status']);
        $allowed_statuses = ['Pending', 'In Progress', 'Resolved'];
        if (in_array($new_status, $allowed_statuses)) {
            $update_status_query = "UPDATE tickets SET status = ? WHERE id = ?";
            $stmt = $conn->prepare($update_status_query);
            $stmt->bind_param("si", $new_status, $ticket_id);

            if ($stmt->execute()) {
                header("Location: view_ticket.php?id=$ticket_id&success=" . urlencode("Status updated to $new_status."));
                exit();
            } else {
                header("Location: view_ticket.php?id=$ticket_id&error=" . urlencode("Error updating status."));
                exit();
            }
        } else {
            header("Location: view_ticket.php?id=$ticket_id&error=" . urlencode("Invalid status value."));
            exit();
        }
    }

    // Handle replies
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_message'])) {
        $message = htmlspecialchars($_POST['reply_message']);
        $reply_query = "INSERT INTO ticket_replies (ticket_id, sender, message) VALUES (?, 'admin', ?)";
        $stmt = $conn->prepare($reply_query);
        $stmt->bind_param("is", $ticket_id, $message);

        if ($stmt->execute()) {
            header("Location: view_ticket.php?id=$ticket_id&success=" . urlencode("Reply added successfully."));
            exit();
        } else {
            header("Location: view_ticket.php?id=$ticket_id&error=" . urlencode("Error adding reply."));
            exit();
        }
    }
} else {
    header("Location: admin.php?error=" . urlencode("Invalid ticket ID."));
    exit();
}
?>
<link rel="stylesheet" href="css/view_ticket.css">

<!-- Ticket Details -->
<h1>Ticket Details</h1>
<?php if (isset($_GET['success'])): ?>
    <p style="color: green;"><?php echo htmlspecialchars($_GET['success']); ?></p>
<?php endif; ?>
<?php if (isset($_GET['error'])): ?>
    <p style="color: red;"><?php echo htmlspecialchars($_GET['error']); ?></p>
<?php endif; ?>

<p><strong>User:</strong> <?php echo htmlspecialchars($ticket['user_name']); ?></p>
<p><strong>Category:</strong> <?php echo htmlspecialchars($ticket['category']); ?></p>
<p><strong>Description:</strong> <?php echo htmlspecialchars($ticket['description']); ?></p>
<p><strong>Status:</strong> <?php echo htmlspecialchars($ticket['status']); ?></p>

<!-- Replies Section -->
<h2>Replies</h2>
<div class="replies">
    <?php if ($replies_result->num_rows > 0): ?>
        <?php while ($reply = $replies_result->fetch_assoc()): ?>
            <p>
                <strong><?php echo $reply['sender'] === 'admin' ? 'Admin' : htmlspecialchars($ticket['user_name']); ?>:</strong>
                <?php echo htmlspecialchars($reply['message']); ?> 
                <span style="font-size: 0.9em; color: gray;">(<?php echo htmlspecialchars($reply['created_at']); ?>)</span>
            </p>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No replies yet.</p>
    <?php endif; ?>
</div>

<!-- Update Ticket Status -->
<h2>Update Ticket Status</h2>
<form method="POST">
    <select name="status" required>
        <option value="Pending" <?php echo $ticket['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
        <option value="In Progress" <?php echo $ticket['status'] === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
        <option value="Resolved" <?php echo $ticket['status'] === 'Resolved' ? 'selected' : ''; ?>>Resolved</option>
    </select>
    <button type="submit" name="update_ticket_status">Update Status</button>
</form>

<!-- Add Reply -->
<h2>Add a Reply</h2>
<form method="POST">
    <textarea name="reply_message" placeholder="Write your reply..." required></textarea>
    <button type="submit">Submit Reply</button>
</form>

<?php include 'includes/footer.html'; ?>
