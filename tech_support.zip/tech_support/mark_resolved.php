<?php
include 'includes/db.php'; // Include the database connection

// Check if 'id' is provided in the URL and is valid
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $ticket_id = intval($_GET['id']); // Sanitize ticket ID

    // Check if the ticket exists before updating
    $check_query = "SELECT id FROM tickets WHERE id = ?";
    $check_stmt = $conn->prepare($check_query);
    if ($check_stmt) {
        $check_stmt->bind_param("i", $ticket_id);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows === 0) {
            // Redirect if the ticket does not exist
            header("Location: admin.php?error=" . urlencode("Ticket ID $ticket_id does not exist."));
            exit();
        }
    } else {
        // Log the error for debugging and redirect
        error_log("Error preparing check query: " . $conn->error);
        header("Location: admin.php?error=" . urlencode("Failed to prepare check query."));
        exit();
    }

    // Prepare the query to update the ticket's status to 'Resolved'
    $update_query = "UPDATE tickets SET status = 'Resolved' WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);

    if ($update_stmt) {
        $update_stmt->bind_param("i", $ticket_id);

        if ($update_stmt->execute()) {
            // Redirect back to the admin dashboard with a success message
            header("Location: admin.php?success=" . urlencode("Ticket ID $ticket_id marked as resolved."));
            exit();
        } else {
            // Log the error and redirect
            error_log("Error updating ticket: " . $update_stmt->error);
            header("Location: admin.php?error=" . urlencode("Failed to update the ticket status."));
            exit();
        }
    } else {
        // Log the error and redirect
        error_log("Error preparing update statement: " . $conn->error);
        header("Location: admin.php?error=" . urlencode("Failed to prepare the update query."));
        exit();
    }
} else {
    // Redirect to the admin dashboard if 'id' is missing or invalid
    header("Location: admin.php?error=" . urlencode("Invalid or missing ticket ID."));
    exit();
}
?>
