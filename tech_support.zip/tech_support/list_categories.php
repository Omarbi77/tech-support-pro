<?php
// Print categories in 'id - label' form for easy copying
include 'includes/db.php';
$dbname = isset($dbname) ? $dbname : 'tech_support_db';

$display_col = null;
$col_check_sql = "SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'categories' ORDER BY ORDINAL_POSITION";
if ($stmt_col = $conn->prepare($col_check_sql)) {
    $stmt_col->bind_param('s', $dbname);
    $stmt_col->execute();
    $res = $stmt_col->get_result();
    while ($col = $res->fetch_assoc()) {
        if ($col['COLUMN_NAME'] === 'category_name' || $col['COLUMN_NAME'] === 'name') {
            $display_col = $col['COLUMN_NAME'];
            break;
        }
        if ($display_col === null && $col['COLUMN_NAME'] !== 'id' && in_array(strtolower($col['DATA_TYPE']), ['varchar','text','char','tinytext','mediumtext','longtext'])) {
            $display_col = $col['COLUMN_NAME'];
        }
    }
    $stmt_col->close();
}

if ($display_col) {
    $sql = "SELECT id, `" . $display_col . "` AS label FROM categories ORDER BY id";
} else {
    $sql = "SELECT id, id AS label FROM categories ORDER BY id";
}

if ($res = $conn->query($sql)) {
    if ($res->num_rows === 0) {
        echo "No categories found in the 'categories' table.\n";
    } else {
        while ($r = $res->fetch_assoc()) {
            echo $r['id'] . " - " . $r['label'] . "\n";
        }
    }
} else {
    echo "Error fetching categories: " . $conn->error . "\n";
}

$conn->close();

?>