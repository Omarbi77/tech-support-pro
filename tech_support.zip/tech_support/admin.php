<?php
session_start();

include 'includes/header.html'; // Include the header
include 'includes/db.php'; // Include the database connection
require_once 'includes/auth.php';
include 'includes/schema.php';
// Ensure user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Get the filter option (default is 'all')
$filter_option = $_GET['filter'] ?? 'all';

// Use central schema info from includes/schema.php
$category_display_column = $CATEGORY_DISPLAY_COLUMN;
$tickets_fk = $TICKETS_FK;
$categories_pk = $CATEGORIES_PK;
$categories_map = $CATEGORIES_MAP;

if ($category_display_column && $tickets_fk) {
    $category_select = "categories.`" . $category_display_column . "` AS category";
    $join_clause = "JOIN categories ON tickets.`" . $tickets_fk . "` = categories.`" . $categories_pk . "`";
} elseif ($tickets_fk) {
    $category_select = "tickets.`" . $tickets_fk . "` AS category_id";
    $join_clause = "";
} else {
    $category_select = "NULL AS category";
    $join_clause = "";
}

// Define base query for tickets
$query_tickets = "SELECT tickets.id, users.name AS user_name, " . $category_select . ", tickets.description, tickets.status, tickets.created_at FROM tickets JOIN users ON tickets.user_id = users.id " . $join_clause;

// Get the filter option (default is 'all')
$filter_option = $_GET['filter'] ?? 'all';
if ($filter_option !== 'all') {
    $query_tickets .= " WHERE tickets.status = ? ORDER BY tickets.created_at DESC";
} else {
    $query_tickets .= " ORDER BY tickets.created_at DESC";
}

$stmt_tickets = $conn->prepare($query_tickets);

if ($filter_option !== 'all') {
    $stmt_tickets->bind_param("s", $filter_option);
}

if (!$stmt_tickets->execute()) {
    die("Error executing query: " . $stmt_tickets->error);
}


$result_tickets = $stmt_tickets->get_result();
// Fetch categories into a map for label lookup (if we only selected FK)
$categories_map = [];
if ($category_display_column) {
    $q = "SELECT id, `" . $category_display_column . "` AS label FROM categories";
    if ($res = $conn->query($q)) {
        while ($r = $res->fetch_assoc()) {
            $categories_map[$r['id']] = $r['label'];
        }
    }
} else {
    // try to at least get ids
    $q = "SELECT id FROM categories";
    if ($res = $conn->query($q)) {
        while ($r = $res->fetch_assoc()) {
            $categories_map[$r['id']] = $r['id'];
        }
    }
}
// Fetch all contact messages
$messages_query = "SELECT * FROM contact_messages ORDER BY created_at DESC";
$messages_result = $conn->query($messages_query);

if ($messages_result->num_rows > 0): ?>
    <h2>Contact Messages</h2>
    <table border="1">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Message</th>
                <th>Received At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($message = $messages_result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($message['name']); ?></td>
                    <td><?= htmlspecialchars($message['email']); ?></td>
                    <td><?= htmlspecialchars($message['message']); ?></td>
                    <td><?= htmlspecialchars($message['created_at']); ?></td>
                    <td>
                        <a href="reply_message.php?id=<?= $message['id']; ?>">Reply</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No messages found.</p>
<?php endif; 
// Fetch user feedback
$feedback_query = "
    SELECT feedback.id, users.name AS user_name, feedback.feedback, feedback.rating, feedback.created_at 
    FROM feedback 
    JOIN users ON feedback.user_id = users.id 
    ORDER BY feedback.created_at DESC";

$feedback_result = $conn->query($feedback_query);
if (!$feedback_result) {
    die("Error fetching feedback: " . $conn->error);
}
?>
<link rel="stylesheet" href="css/admin_dashboard.css">

<div class="admin-dashboard">
    <!-- Dashboard Header -->
    <div class="dashboard-header">
        <h1>Admin Dashboard</h1>
        <a href="logout.php" class="btn btn-logout">Logout</a>
    </div>

    <!-- Success and Error Messages -->
    <?php if (isset($_GET['success'])): ?>
        <p class="success-message"><?php echo htmlspecialchars($_GET['success']); ?></p>
    <?php endif; ?>
    <?php if (isset($_GET['error'])): ?>
        <p class="error-message"><?php echo htmlspecialchars($_GET['error']); ?></p>
    <?php endif; ?>

    <!-- Filter Options -->
    <form action="admin.php" method="GET" class="filter-form">
        <label for="filter">Filter Tickets By Status:</label>
        <select id="filter" name="filter" onchange="this.form.submit()">
            <option value="all" <?= $filter_option === 'all' ? 'selected' : '' ?>>Show All</option>
            <option value="Pending" <?= $filter_option === 'Pending' ? 'selected' : '' ?>>Pending</option>
            <option value="In Progress" <?= $filter_option === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
            <option value="Resolved" <?= $filter_option === 'Resolved' ? 'selected' : '' ?>>Resolved</option>
        </select>
    </form>

    <!-- Submitted Tickets -->
    <h2>Submitted Tickets</h2>
    <table class="dashboard-table">
        <thead>
            <tr>
                <th>User</th>
                <th>Category</th>
                <th>Description</th>
                <th>Status</th>
                <th>Submitted At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result_tickets->num_rows > 0): ?>
                <?php while ($ticket = $result_tickets->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($ticket['user_name']); ?></td>
                        <td>
                            <?php
                            if (isset($ticket['category'])) {
                                echo htmlspecialchars($ticket['category']);
                            } elseif (isset($ticket['category_id'])) {
                                $cid = $ticket['category_id'];
                                echo htmlspecialchars($categories_map[$cid] ?? $cid);
                            } else {
                                echo 'N/A';
                            }
                            ?>
                        </td>
                        <td><?= htmlspecialchars($ticket['description']); ?></td>
                        <td><?= htmlspecialchars($ticket['status']); ?></td>
                        <td><?= htmlspecialchars($ticket['created_at']); ?></td>
                        <td>
                            <a href="update_ticket_status.php?id=<?= $ticket['id']; ?>&status=Resolved" class="btn btn-action">Mark Resolved</a>
                            <a href="update_ticket_status.php?id=<?= $ticket['id']; ?>&status=In Progress" class="btn btn-action">Mark In Progress</a>
                            <a href="view_ticket.php?id=<?= $ticket['id']; ?>" class="btn btn-action">View Details</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="no-data">No tickets found for the selected filter.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Feedback Section -->
    <h2>User Feedback</h2>
    <table class="dashboard-table">
        <thead>
            <tr>
                <th>User</th>
                <th>Feedback</th>
                <th>Rating</th>
                <th>Submitted At</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($feedback_result->num_rows > 0): ?>
                <?php while ($feedback = $feedback_result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($feedback['user_name']); ?></td>
                        <td><?= htmlspecialchars($feedback['feedback']); ?></td>
                        <td><?= htmlspecialchars($feedback['rating']); ?>/5</td>
                        <td><?= htmlspecialchars($feedback['created_at']); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="no-data">No feedback found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>




<?php include 'includes/footer.html'; ?>
