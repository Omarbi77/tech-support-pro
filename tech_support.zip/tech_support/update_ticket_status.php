<?php
include 'includes/db.php'; // Include the database connection

// Validate and sanitize the inputs
if (isset($_GET['id']) && isset($_GET['status']) && is_numeric($_GET['id'])) {
    $ticket_id = intval($_GET['id']); // Sanitize ticket ID
    $status = htmlspecialchars($_GET['status']); // Sanitize status input

    // Validate the status value
    $allowed_statuses = ['Pending', 'In Progress', 'Resolved'];
    if (!in_array($status, $allowed_statuses)) {
        header("Location: admin.php?error=" . urlencode("Invalid status value."));
        exit();
    }

    // Prepare the query to update the ticket status
    $query = "UPDATE tickets SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        $stmt->bind_param("si", $status, $ticket_id);

        // Execute the query and check for success
        if ($stmt->execute()) {
            header("Location: admin.php?success=" . urlencode("Ticket status updated to " . $status . "."));
            exit();
        } else {
            // Log error and redirect with a failure message
            error_log("Error updating ticket: " . $stmt->error);
            header("Location: admin.php?error=" . urlencode("Error updating ticket."));
            exit();
        }
    } else {
        // Log error and redirect with a failure message
        error_log("Error preparing statement: " . $conn->error);
        header("Location: admin.php?error=" . urlencode("Error preparing the query."));
        exit();
    }
} else {
    // Redirect if required parameters are missing or invalid
    header("Location: admin.php?error=" . urlencode("Invalid or missing parameters."));
    exit();
}
?>
