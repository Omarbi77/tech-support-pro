<?php
session_start();
include 'includes/db.php'; // Include the database connection
include 'includes/schema.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Validate and sanitize the ticket ID
$ticket_id = null;
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $ticket_id = intval($_GET['id']); // Admin access
} elseif (isset($_POST['ticket_id']) && is_numeric($_POST['ticket_id'])) {
    $ticket_id = intval($_POST['ticket_id']); // User access
} else {
    echo "<p>No ticket selected.</p>";
    include 'includes/footer.php';
    exit();
}

// Use central schema variables
$category_display_column = $CATEGORY_DISPLAY_COLUMN;
$tickets_fk = $TICKETS_FK;
$categories_pk = $CATEGORIES_PK;

if ($category_display_column && $tickets_fk) {
    $select_cat = "categories.`" . $category_display_column . "` AS category";
    $join_clause = "JOIN categories ON tickets.`" . $tickets_fk . "` = categories.`" . $categories_pk . "`";
} elseif ($tickets_fk) {
    $select_cat = "tickets.`" . $tickets_fk . "` AS category_id";
    $join_clause = "";
} else {
    $select_cat = "NULL AS category";
    $join_clause = "";
}

$query = "SELECT tickets.*, users.name AS user_name, " . $select_cat . " FROM tickets JOIN users ON tickets.user_id = users.id " . $join_clause . " WHERE tickets.id = ?";

// Prepare and execute the query
$stmt = $conn->prepare($query);
if ($stmt) {
    $stmt->bind_param("i", $ticket_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $ticket = $result->fetch_assoc(); // Fetch ticket details
    } else {
        echo "<p>Ticket not found or you do not have permission to view it.</p>";
        include 'includes/footer.php';
        exit();
    }
} else {
    error_log("Error preparing statement: " . $conn->error);
    echo "<p>Error loading ticket details. Please try again later.</p>";
    include 'includes/footer.php';
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Ticket</title>
    <link rel="stylesheet" href="css/view_ticket.css">
</head>
<body>
    <div class="ticket-details">
        <h1>Ticket Details</h1>
        <?php if ($_SESSION['role'] === 'admin'): ?>
            <p><strong>User:</strong> <?= htmlspecialchars($ticket['user_name']); ?></p>
        <?php endif; ?>
        <p><strong>Category:</strong>
            <?php
            if (isset($ticket['category'])) {
                echo htmlspecialchars($ticket['category']);
            } elseif (isset($ticket['category_id'])) {
                // try to look up the label
                $label = null;
                $q = $conn->prepare("SELECT id, COALESCE(category_name, name) AS label FROM categories WHERE id = ? LIMIT 1");
                if ($q) {
                    $cat_id = $ticket['category_id'];
                    $q->bind_param('i', $cat_id);
                    $q->execute();
                    $resq = $q->get_result();
                    if ($resq && $resq->num_rows > 0) {
                        $row = $resq->fetch_assoc();
                        $label = $row['label'];
                    }
                    $q->close();
                }
                echo htmlspecialchars($label ?? $ticket['category_id']);
            } else {
                echo 'N/A';
            }
            ?>
        </p>
        <p><strong>Description:</strong> <?= htmlspecialchars($ticket['description']); ?></p>
        <p><strong>Status:</strong> <?= htmlspecialchars($ticket['status']); ?></p>
        <p><strong>Submitted At:</strong> <?= htmlspecialchars($ticket['created_at']); ?></p>
        <a href="<?= $_SESSION['role'] === 'admin' ? 'admin.php' : 'dashboard.php'; ?>" class="btn-back">Back to <?= $_SESSION['role'] === 'admin' ? 'Dashboard' : 'Tickets'; ?></a>
    </div>
</body>
</html>
