<?php
session_start();
include 'includes/db.php'; // Include database connection
require 'vendor/autoload.php'; // Include PHPMailer (Composer Autoloader)

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Ensure the user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Validate message ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: admin.php?error=" . urlencode("Invalid message ID."));
    exit();
}

$message_id = intval($_GET['id']);

// Fetch the message details
$message_query = "SELECT * FROM contact_messages WHERE id = ?";
$stmt = $conn->prepare($message_query);
$stmt->bind_param("i", $message_id);
$stmt->execute();
$message_result = $stmt->get_result();

if ($message_result->num_rows === 0) {
    header("Location: admin.php?error=" . urlencode("Message not found."));
    exit();
}

$message = $message_result->fetch_assoc();

// Handle reply submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply'])) {
    $reply = htmlspecialchars(trim($_POST['reply']));
    $admin_id = $_SESSION['user_id'];

    if (!empty($reply)) {
        // Insert reply into the database
        $reply_query = "INSERT INTO contact_replies (message_id, admin_id, reply) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($reply_query);
        $stmt->bind_param("iis", $message_id, $admin_id, $reply);

        if ($stmt->execute()) {
            // Send the reply via email
            $emailConfig = include 'email_config.php';
            $mail = new PHPMailer(true);
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host = $emailConfig['smtp_host'];
                $mail->SMTPAuth = true;
                $mail->Username = $emailConfig['smtp_username'];
                $mail->Password = $emailConfig['smtp_password'];
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = $emailConfig['smtp_port'];
                $mail->SMTPDebug = 2; // Equivalent to PHPMailer::DEBUG_SERVER

                $mail->SMTPDebug = 2; // Verbose output
$mail->Debugoutput = 'html'; // Debug output format


                // Recipients
                $mail->setFrom($emailConfig['from_email'], $emailConfig['from_name']);
                $mail->addAddress($message['email'], $message['name']); // Recipient's email

                // Content
                $mail->Subject = 'Reply to Your Contact Message';
                $mail->Body = "Dear " . htmlspecialchars($message['name']) . ",\n\n" .
                              "Thank you for contacting us. Here is our reply to your message:\n\n" .
                              htmlspecialchars($reply) . "\n\n" .
                              "Best regards,\nAdmin Team";

                // Send email
                $mail->send();
                header("Location: admin.php?success=" . urlencode("Reply sent successfully, and email was delivered."));
                exit();
            } catch (Exception $e) {
                error_log("Email sending failed: " . $mail->ErrorInfo);
                $error = "Reply saved, but email could not be sent. Please try again later.";
            }
        } else {
            $error = "Error saving reply.";
        }
    } else {
        $error = "Reply cannot be empty.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reply to Message</title>
</head>
<body>
    <h1>Reply to Message</h1>
    <p><strong>Name:</strong> <?= htmlspecialchars($message['name']); ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($message['email']); ?></p>
    <p><strong>Message:</strong> <?= htmlspecialchars($message['message']); ?></p>
    <p><strong>Received At:</strong> <?= htmlspecialchars($message['created_at']); ?></p>

    <?php if (isset($error)): ?>
        <p style="color: red;"><?= htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form method="POST">
        <textarea name="reply" rows="5" placeholder="Write your reply here..." required></textarea>
        <button type="submit">Send Reply</button>
    </form>
</body>
</html>
