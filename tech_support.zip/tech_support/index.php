<?php include 'includes/header.html'; // Include header section (navigation, meta tags, etc.) ?>
<link rel="stylesheet" href="css/index.css">
<!-- Hero Section: The introductory section of the website -->
<div class="hero">
    <div class="hero-content">
        <!-- Main Heading: Welcoming message to users -->
        <h1>Welcome to Tech Support Pro</h1>
        <!-- Subheading: Brief description of services -->
        <p>Your one-stop solution for IT services and support.</p>
        <!-- Call-to-action Buttons: Encouraging users to take action -->
        <a href="services.php" class="btn">Explore Our Services</a>
        <a href="register.php" class="btn btn-secondary">Get Started</a>
    </div>
</div>
<!-- Features Section: Highlighting the key features of the service -->
 
<div class="features">
    <h2>Why Choose Us?</h2> <!-- Section heading -->
    <div class="feature-list">
        <!-- Feature 1: 24/7 Support -->
        <div class="feature-item">
            <img src="css/images/icon-support.png" alt="Support Icon"> <!-- Feature icon -->
            <h3>24/7 Support</h3> <!-- Feature heading -->
            <p>We are available around the clock to assist you with your IT needs.</p> <!-- Feature description -->
        </div>
        <!-- Feature 2: Affordable Pricing -->
        <div class="feature-item">
            <img src="css/images/icon-pricing.png" alt="Pricing Icon"> <!-- Feature icon -->
            <h3>Affordable Pricing</h3> <!-- Feature heading -->
            <p>High-quality tech support at prices that won't break the bank.</p> <!-- Feature description -->
        </div>
        <!-- Feature 3: Certified Technicians -->
        <div class="feature-item">
            <img src="css/images/icon-certified.png" alt="Certified Icon"> <!-- Feature icon -->
            <h3>Certified Technicians</h3> <!-- Feature heading -->
            <p>Our team consists of highly skilled and certified professionals.</p> <!-- Feature description -->
        </div>
    </div>
</div>
<div class="profile-actions">
    
</div>



<?php include 'includes/footer.html'; // Include footer section (contact info, social media, etc.) ?>
