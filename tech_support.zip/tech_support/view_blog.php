<?php
include 'includes/header.html'; // Include the header section
include 'includes/db.php'; // Include the database connection

// Check if a blog ID is passed in the URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $blog_id = intval($_GET['id']); // Get and sanitize the blog ID

    // Prepare and execute a secure query to fetch the blog post
    $query = "SELECT * FROM blogs WHERE id = ?";
    $stmt = $conn->prepare($query); // Use a prepared statement to prevent SQL injection
    $stmt->bind_param("i", $blog_id); // Bind the blog ID parameter
    $stmt->execute();
    $result = $stmt->get_result(); // Fetch the query result

    // Check if the blog post exists
    if ($result->num_rows > 0) {
        $blog = $result->fetch_assoc(); // Fetch the blog data as an associative array
    } else {
        // If no blog post is found, display an error message
        echo "<p class='error-message'>Blog post not found.</p>";
        include 'includes/footer.php';
        exit();
    }
} else {
    // If no valid blog ID is provided, redirect to the blog list or homepage
    header("Location: blog.php");
    exit();
}
?>
<link rel="stylesheet" href="css/single_blog.css">
<!-- Single Blog Hero Section -->
<div class="single-blog-hero">
    <div class="single-blog-hero-content">
        <h1><?php echo htmlspecialchars($blog['title']); ?></h1> <!-- Display the blog title -->
        <p class="blog-date">Posted on: <?php echo date("F j, Y", strtotime($blog['created_at'])); ?></p> <!-- Display the blog post date -->
    </div>
</div>

<!-- Single Blog Content Section -->
<div class="single-blog-content">
    <div class="blog-image">
        <img src="css/images/<?php echo htmlspecialchars($blog['image_url']); ?>" alt="<?php echo htmlspecialchars($blog['title']); ?>" /> <!-- Display the blog image -->
    </div>

    <div class="blog-text-content">
        <p><?php echo nl2br(htmlspecialchars($blog['content'])); ?></p> <!-- Display the blog content with line breaks -->
    </div>
</div>

<?php include 'includes/footer.html'; // Include the footer section ?>
