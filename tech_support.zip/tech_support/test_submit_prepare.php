<?php
// Quick test to validate prepare() for submit_issue.php logic
include 'includes/db.php';
$dbname = isset($dbname) ? $dbname : 'tech_support_db';

// detect tickets fk as submit_issue does
$tickets_fk = 'category_id';
$tickets_cols_sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'tickets' ORDER BY ORDINAL_POSITION";
if ($stmt_tc = $conn->prepare($tickets_cols_sql)) {
    $stmt_tc->bind_param("s", $dbname);
    $stmt_tc->execute();
    $res_tc = $stmt_tc->get_result();
    $preferred = ['category_id','categoryid','category','cat_id','catid'];
    while ($c = $res_tc->fetch_assoc()) {
        $colname = $c['COLUMN_NAME'];
        foreach ($preferred as $p) {
            if (strcasecmp($colname, $p) === 0) {
                $tickets_fk = $colname;
                break 2;
            }
        }
        if ($tickets_fk === 'category_id' && (stripos($colname, 'category') !== false || stripos($colname, 'cat') !== false)) {
            $tickets_fk = $colname;
        }
    }
    $stmt_tc->close();
}

$query = "INSERT INTO tickets (user_id, `" . $tickets_fk . "`, description, status) VALUES (?, ?, ?, 'Pending')";
$stmt = $conn->prepare($query);
if (!$stmt) {
    echo "Prepare failed: " . $conn->error . "\n";
} else {
    echo "Prepare successful. Using FK column: $tickets_fk\n";
}
$conn->close();
?>