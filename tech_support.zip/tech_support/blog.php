<?php
include 'includes/header.html'; // Includes the reusable header
include 'includes/db.php'; // Includes database connection
// Fetch all blogs from the database, ordered by creation date (latest first)
$query = "SELECT * FROM blogs ORDER BY created_at DESC";
$result = $conn->query($query); // Execute the query
?>
<link rel= "stylesheet" href="css/blog.css">
<link rel= "stylesheet" href="css/singl_blog.css">
<!-- Hero Section for the Blog Page -->
<div class="blogs-hero">
    <div class="blogs-hero-content">
        <h1>Our Blog</h1> <!-- Main heading for the blog page -->
        <p>Stay updated with the latest news and insights from the tech world.</p> <!-- Subheading to describe the purpose of the blog -->
    </div>
</div>

<!-- Blog Listing Section -->
<div class="blog-list">
    <?php
    if ($result->num_rows > 0) { // Check if there are any blog posts
        while ($row = $result->fetch_assoc()) { // Loop through each blog post
            echo "<div class='blog-post'>";

            // Blog Image Section
            echo "<div class='blog-image'>";
            echo "<img src='css/images/" . htmlspecialchars($row['image_url']) . "' alt='" . htmlspecialchars($row['title']) . "'>"; // Display the blog image
            echo "</div>";

            // Blog Content Section
            echo "<div class='blog-content'>";
            echo "<h2>" . htmlspecialchars($row['title']) . "</h2>"; // Blog title
            echo "<p><strong>Category:</strong> " . htmlspecialchars($row['category']) . "</p>"; // Blog category
            echo "<p>" . substr(htmlspecialchars($row['content']), 0, 150) . "...</p>"; // Blog content preview (first 150 characters)
            echo "<a href='view_blog.php?id=" . $row['id'] . "' class='btn'>Read More</a>"; // Link to view the full blog post
            echo "</div>";

            echo "</div>"; // End of blog-post
        }
    } else {
        echo "<p>No blog posts available at the moment.</p>"; // Display message if no blogs are found
    }
    ?>
</div>

<?php include 'includes/footer.html'; // Includes the reusable footer ?>
