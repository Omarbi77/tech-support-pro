
<link rel="stylesheet"href="css/logout.css">
<?php
require_once 'includes/auth.php';
session_start(); // Start the session to access session data

// Save the user's role if it exists
$role = $_SESSION['role'] ?? null;

// Clear all session variables and destroy the session
session_unset(); // Remove all session variables
session_destroy(); // Completely destroy the session

// Redirect the user based on their role
if ($role === 'admin') {
    header("Location: admin.php"); // Redirect admin users to the admin login page
}
 else {
    header("Location: login.php"); // Redirect regular users or unknown roles to the login page
}
exit(); // Ensure no further code is executed

