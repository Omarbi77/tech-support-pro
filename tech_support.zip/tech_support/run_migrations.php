<?php
// Helper to run migration SQL files in the database
include 'includes/db.php';
$migration = __DIR__ . '/database/create_contact_replies.sql';
if (!file_exists($migration)) {
    echo "Migration file not found: $migration\n";
    exit(1);
}
$sql = file_get_contents($migration);
if ($conn->multi_query($sql)) {
    do {
        if ($res = $conn->store_result()) {
            $res->free();
        }
    } while ($conn->more_results() && $conn->next_result());
    echo "Migration executed successfully.\n";
} else {
    echo "Migration failed: " . $conn->error . "\n";
}
$conn->close();
?>