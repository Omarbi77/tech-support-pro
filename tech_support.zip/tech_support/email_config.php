<?php
// Email Configuration
return [
    'smtp_host' => 'smtp.office365.com', // SMTP server
    'smtp_port' => 587,                  // TLS port
    'smtp_username' => 'omaralotaibi-99@hotmail.com', // Your full email
    'smtp_password' => 'cuboklxbuhcfefqp', // Your App Password
    'from_email' => 'omaralotaibi-99@hotmail.com',    // Sender's email
    'from_name' => 'Admin',              // Sender's name
];
