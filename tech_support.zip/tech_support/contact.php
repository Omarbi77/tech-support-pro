<?php
// Include the header and database connection
include 'includes/header.html'; 
include 'includes/db.php'; 

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars($_POST['name']); // Sanitize input (Name)
    $email = htmlspecialchars($_POST['email']); // Sanitize input (Email)
    $message = htmlspecialchars($_POST['message']); // Sanitize input (Message)

    // Insert the data into the database
    $query = "INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query); // Use prepared statements to avoid SQL injection
    $stmt->bind_param("sss", $name, $email, $message);

    if ($stmt->execute()) {
        $successMessage = "Message sent successfully! We will get back to you shortly.";
    } else {
        $errorMessage = "Error: " . $stmt->error; // Error handling
    }
}

?>

<link rel="stylesheet" href="css/contact.css">
<!-- Hero Section -->
<div class="contact-hero">
    <h1>Contact Us</h1>
    <p>We’d love to hear from you! Feel free to reach out to us with any questions or feedback.</p>
</div>

<!-- Contact Section -->
<div class="contact-section">
    <!-- Contact Form -->
    <div class="form-container">
        <?php if (isset($successMessage)): ?>
            <p class="success-message"><?= $successMessage ?></p>
        <?php elseif (isset($errorMessage)): ?>
            <p class="error-message"><?= $errorMessage ?></p>
        <?php endif; ?>
        
        <form action="" method="POST" class="contact-form">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <textarea name="message" placeholder="Your Message" required></textarea>
            <button type="submit">Send Message</button>
        </form>
    </div>

    <!-- Contact Information -->
    <div class="contact-info">
        <h3>Our Contact Info</h3>
        <p><strong>Address:</strong> Saudi Arabia, Riyadh</p>
        <p><strong>Email:</strong> alotaibiomar7@outlook.sa</p>
        <p><strong>Phone:</strong> +966557312124</p>
        
        <!-- Social Media Links -->
        <div class="social-links">
            <a href="https://snapchat.com/t/KV6dsEEh">
                <img src="css/images/SnapChat-icon.png" alt="SnapChat">
            </a>
            
            <a href="https://X.com/@omarbi77">
                <img src="css/images/X-icon.png" alt="X">
            </a>
            <a href="https://linkedin.com/in/Omar-Alotaibi-200146201">
                <img src="css/images/linkedin-icon.png" alt="LinkedIn">
            </a>
        </div>
    </div>
</div>

<?php 
// Include the footer
include 'includes/footer.html'; 
?>
