<?php

include 'includes/db.php';

$categories = [
    'Software Issue',
    'Hardware Issue',
    'Network / Connectivity',
    'Account / Login',
    'Billing / Payments',
    'Installation / Setup',
    'Performance / Slow',
    'Security / Vulnerability',
    'Feature Request',
    'Other'
];

$inserted = [];

// Determine the textual display column (prefer category_name or name)
$display_col = null;
$col_check_sql = "SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'categories' ORDER BY ORDINAL_POSITION";
if ($stmt_col = $conn->prepare($col_check_sql)) {
    $stmt_col->bind_param('s', $dbname);
    $stmt_col->execute();
    $res = $stmt_col->get_result();
    while ($col = $res->fetch_assoc()) {
        if (in_array($col['COLUMN_NAME'], ['category_name','name'])) {
            $display_col = $col['COLUMN_NAME'];
            break;
        }
        if ($display_col === null && $col['COLUMN_NAME'] !== 'id' && in_array(strtolower($col['DATA_TYPE']), ['varchar','text','char','tinytext','mediumtext','longtext'])) {
            $display_col = $col['COLUMN_NAME'];
        }
    }
    $stmt_col->close();
}

// If no textual display column exists, add `category_name`
if (!$display_col) {
    if ($conn->query("ALTER TABLE categories ADD COLUMN category_name VARCHAR(100) NULL")) {
        $display_col = 'category_name';
    } else {
        die("Failed to add category_name column: " . $conn->error);
    }
}

foreach ($categories as $cat) {
    // Case-insensitive check using the detected display column
    $sql_check = "SELECT id FROM categories WHERE LOWER(`" . $display_col . "`) = LOWER(?) LIMIT 1";
    if ($check = $conn->prepare($sql_check)) {
        $check->bind_param('s', $cat);
        $check->execute();
        $r = $check->get_result();
        if ($r && $r->num_rows > 0) {
            $check->close();
            continue;
        }
        $check->close();
    }
    // Insert into the display column
    $ins_sql = "INSERT INTO categories (`" . $display_col . "`) VALUES (?)";
    if ($ins = $conn->prepare($ins_sql)) {
        $ins->bind_param('s', $cat);
        if ($ins->execute()) {
            $inserted[] = $cat;
        }
        $ins->close();
    }
}

if (count($inserted) > 0) {
    echo "Inserted categories:\n";
    foreach ($inserted as $c) echo "- $c\n";
} else {
    echo "No new categories inserted. They may already exist.\n";
}

$conn->close();
?>