<?php
// Sanitize input to prevent XSS attacks
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Validate email format
function isEmailValid($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Check if a string contains only letters and spaces
function isAlpha($string) {
    return ctype_alpha(str_replace(' ', '', $string));
}

// Validate password strength
function isStrongPassword($password) {
    return preg_match('/^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$/', $password);
}
?>
