<?php
// Central schema detection helper. Assumes $conn and $dbname are set (include after includes/db.php)
// Exposes: $TICKETS_FK, $CATEGORY_DISPLAY_COLUMN, $CATEGORIES_PK, $CATEGORIES_MAP and function category_label($id)

// Avoid re-running detection
if (!isset($SCHEMA_DETECTED) || !$SCHEMA_DETECTED) {
    $SCHEMA_DETECTED = true;

    $TICKETS_FK = null;
    $CATEGORY_DISPLAY_COLUMN = null;
    $CATEGORIES_PK = 'id';
    $CATEGORIES_MAP = [];

    // detect category display column
    $col_check_sql = "SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'categories' ORDER BY ORDINAL_POSITION";
    if ($stmt = $conn->prepare($col_check_sql)) {
        $stmt->bind_param('s', $dbname);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($col = $res->fetch_assoc()) {
            if (in_array($col['COLUMN_NAME'], ['category_name','name'])) {
                $CATEGORY_DISPLAY_COLUMN = $col['COLUMN_NAME'];
                break;
            }
            if ($CATEGORY_DISPLAY_COLUMN === null && $col['COLUMN_NAME'] !== 'id' && in_array(strtolower($col['DATA_TYPE']), ['varchar','text','char','tinytext','mediumtext','longtext'])) {
                $CATEGORY_DISPLAY_COLUMN = $col['COLUMN_NAME'];
            }
        }
        $stmt->close();
    }

    // detect tickets fk
    $tickets_cols_sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'tickets' ORDER BY ORDINAL_POSITION";
    if ($stmt = $conn->prepare($tickets_cols_sql)) {
        $stmt->bind_param('s', $dbname);
        $stmt->execute();
        $res = $stmt->get_result();
        $preferred = ['category_id','categoryid','category','cat_id','catid'];
        while ($c = $res->fetch_assoc()) {
            $colname = $c['COLUMN_NAME'];
            foreach ($preferred as $p) {
                if (strcasecmp($colname, $p) === 0) {
                    $TICKETS_FK = $colname;
                    break 2;
                }
            }
            if ($TICKETS_FK === null && (stripos($colname, 'category') !== false || stripos($colname, 'cat') !== false)) {
                $TICKETS_FK = $colname;
            }
        }
        $stmt->close();
    }

    // detect categories pk
    $pk_sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'categories' AND COLUMN_KEY = 'PRI' LIMIT 1";
    if ($stmt = $conn->prepare($pk_sql)) {
        $stmt->bind_param('s', $dbname);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $CATEGORIES_PK = $row['COLUMN_NAME'];
        }
        $stmt->close();
    }

    // build categories map for labels
    if ($CATEGORY_DISPLAY_COLUMN) {
        $sql = "SELECT `" . $CATEGORIES_PK . "` AS id, `" . $CATEGORY_DISPLAY_COLUMN . "` AS label FROM categories";
        if ($res = $conn->query($sql)) {
            while ($r = $res->fetch_assoc()) {
                $CATEGORIES_MAP[$r['id']] = $r['label'];
            }
        }
    } else {
        // at least collect ids
        $sql = "SELECT `" . $CATEGORIES_PK . "` AS id FROM categories";
        if ($res = $conn->query($sql)) {
            while ($r = $res->fetch_assoc()) {
                $CATEGORIES_MAP[$r['id']] = $r['id'];
            }
        }
    }

    // helper function
    function category_label($id) {
        global $CATEGORIES_MAP, $conn, $CATEGORY_DISPLAY_COLUMN, $CATEGORIES_PK;
        if (isset($CATEGORIES_MAP[$id])) return $CATEGORIES_MAP[$id];
        if ($CATEGORY_DISPLAY_COLUMN) {
            $q = $conn->prepare("SELECT `" . $CATEGORY_DISPLAY_COLUMN . "` AS label FROM categories WHERE `" . $CATEGORIES_PK . "` = ? LIMIT 1");
            if ($q) {
                $q->bind_param('i', $id);
                $q->execute();
                $res = $q->get_result();
                if ($res && $row = $res->fetch_assoc()) return $row['label'];
            }
        }
        return $id;
    }
}
