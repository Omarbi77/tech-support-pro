<?php
// Database connection details
$servername = "localhost";  // Server name or IP address where the MySQL database is hosted
$username = "root";         // Username for MySQL login (default is usually 'root')
$password = "";             // Password for the database user (empty here for localhost, but ideally use a secure password)
$dbname = "tech_support_db"; // Name of the database to connect to

try {
    // Create connection using mysqli object-oriented approach
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check if connection was successful
    if ($conn->connect_error) {
        // If there is an error, throw an exception with the error message
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Optional: Set character set for the connection to UTF-8 for proper encoding
    // This ensures that any data sent to/from the database will use UTF-8 encoding
    $conn->set_charset("utf8");

} catch (Exception $e) {
    // If there's an exception, terminate the script and show the error message
    die("Database connection error: " . $e->getMessage());
}
?>
