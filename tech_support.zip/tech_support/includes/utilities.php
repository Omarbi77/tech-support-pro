<?php
// Redirect to another page
function redirect($url) {
    header("Location: $url");
    exit();
}

// Format a date for consistent display
function formatDate($date) {
    return date("F j, Y, g:i a", strtotime($date));
}

// Log errors to a file
function logError($message) {
    $filePath = __DIR__ . '/../logs/errors.log';
    $timestamp = date('Y-m-d H:i:s');
    error_log("[$timestamp] $message\n", 3, $filePath);
}
?>
