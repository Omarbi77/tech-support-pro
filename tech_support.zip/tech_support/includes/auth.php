<?php
// Start a session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is authenticated
function isAuthenticated() {
    return isset($_SESSION['user_id']);
}

// Require authentication for protected pages
function requireAuth() {
    if (!isAuthenticated()) {
        header("Location:login.php"); // Redirect to login if not authenticated
        exit();
    }
}

// Log out the user
function logout() {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
