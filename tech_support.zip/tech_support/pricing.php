<?php include 'includes/header.html'; ?>
<link rel= "stylesheet" href="css/pricing.css">
<!-- Hero Section for Pricing Page -->
<div class="pricing-hero">
    <div class="pricing-hero-content">
        <h1>Our Pricing Plans</h1>
        <p>Choose the perfect IT solution tailored to your needs at affordable prices.</p>
    </div>
</div>

<!-- Pricing Section -->
<div class="pricing">
    <div class="pricing-table">
        <!-- Pricing Plan 1: Laptop Repair -->
        <div class="pricing-item best-offer">
            <img src="css/images/icon-laptop.png" alt="Icon representing Laptop Repair service" />
            <h2>Laptop Repair</h2>
            <ul class="features">
                <li>Hardware diagnostics</li>
                <li>Software troubleshooting</li>
                <li>Quick turnaround time</li>
            </ul>
            <p class="price"><span class="original-price">$60</span> $50</p>
            <a href="service-details.php?service=laptop-repair" class="btn">Learn More</a>
        </div>

        <!-- Pricing Plan 2: Network Setup -->
        <div class="pricing-item">
            <img src="css/images/icon-network.png" alt="Icon representing Network Setup service" />
            <h2>Network Setup</h2>
            <ul class="features">
                <li>Full network installation</li>
                <li>Secure configuration</li>
                <li>24/7 tech support</li>
            </ul>
            <p class="price">$75</p>
            <a href="service-details.php?service=network-setup" class="btn">Learn More</a>
        </div>

        <!-- Pricing Plan 3: Data Recovery -->
        <div class="pricing-item">
            <img src="css/images/icon-data-recovery.png" alt="Icon representing Data Recovery service" />
            <h2>Data Recovery</h2>
            <ul class="features">
                <li>Advanced recovery tools</li>
                <li>Secure handling</li>
                <li>Guaranteed results</li>
            </ul>
            <p class="price">$100</p>
            <a href="service-details.php?service=data-recovery" class="btn">Learn More</a>
        </div>

        <!-- Pricing Plan 4: IT Consultation -->
        <div class="pricing-item">
            <img src="css/images/icon-consultation.png" alt="Icon representing IT Consultation service" />
            <h2>IT Consultation</h2>
            <ul class="features">
                <li>Expert advice</li>
                <li>Custom IT strategies</li>
                <li>Actionable insights</li>
            </ul>
            <p class="price">$150</p>
            <a href="service-details.php?service=it-consultation" class="btn">Learn More</a>
        </div>
    </div>
</div>

<?php include 'includes/footer.html'; ?>
