<?php
include 'includes/db.php';
$dbname = isset($dbname) ? $dbname : 'tech_support_db';

// Copy detection from view_ticket.php
$category_display_column = null;
$col_check_sql = "SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'categories' ORDER BY ORDINAL_POSITION";
if ($stmt_col = $conn->prepare($col_check_sql)) {
    $stmt_col->bind_param("s", $dbname);
    $stmt_col->execute();
    $res = $stmt_col->get_result();
    while ($col = $res->fetch_assoc()) {
        if (in_array($col['COLUMN_NAME'], ['category_name','name'])) {
            $category_display_column = $col['COLUMN_NAME'];
            break;
        }
        if ($category_display_column === null && $col['COLUMN_NAME'] !== 'id' && in_array(strtolower($col['DATA_TYPE']), ['varchar','text','char','tinytext','mediumtext','longtext'])) {
            $category_display_column = $col['COLUMN_NAME'];
        }
    }
    $stmt_col->close();
}

$tickets_fk = null;
$tickets_cols_sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'tickets' ORDER BY ORDINAL_POSITION";
if ($stmt_tc = $conn->prepare($tickets_cols_sql)) {
    $stmt_tc->bind_param("s", $dbname);
    $stmt_tc->execute();
    $res_tc = $stmt_tc->get_result();
    $preferred = ['category_id','categoryid','category','cat_id','catid'];
    while ($c = $res_tc->fetch_assoc()) {
        $colname = $c['COLUMN_NAME'];
        foreach ($preferred as $p) {
            if (strcasecmp($colname, $p) === 0) {
                $tickets_fk = $colname;
                break 2;
            }
        }
        if ($tickets_fk === null && (stripos($colname, 'category') !== false || stripos($colname, 'cat') !== false)) {
            $tickets_fk = $colname;
        }
    }
    $stmt_tc->close();
}

$join_clause = '';
if ($category_display_column && $tickets_fk) {
    $select_cat = "categories.`" . $category_display_column . "` AS category";
    $join_clause = "JOIN categories ON tickets.`" . $tickets_fk . "` = categories.id";
} elseif ($tickets_fk) {
    $select_cat = "tickets.`" . $tickets_fk . "` AS category_id";
} else {
    $select_cat = "NULL AS category";
}

$query = "SELECT tickets.*, users.name AS user_name, " . $select_cat . " FROM tickets JOIN users ON tickets.user_id = users.id " . $join_clause . " WHERE tickets.id = ?";

$stmt = $conn->prepare($query);
if (!$stmt) {
    echo "Prepare failed: " . $conn->error . "\n";
} else {
    echo "Prepare successful for view_ticket query.\n";
}
$conn->close();
?>