<?php
session_start();
include 'includes/header.html'; // Include header
include 'includes/db.php'; // Include database connection
require_once 'includes/auth.php';
requireAuth();
include 'includes/schema.php';


// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
// Ensure the user is logged in

// Get the filter option (default is 'all')
$filter_option = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Define query based on filter
// Check whether the categories table contains the expected 'category_name' column.
// Use central schema detection
$category_display_column = $CATEGORY_DISPLAY_COLUMN;
$tickets_fk = $TICKETS_FK;
$categories_pk = $CATEGORIES_PK;
$categories_map = $CATEGORIES_MAP;

if ($category_display_column && $tickets_fk) {
    $category_select = "categories.`" . $category_display_column . "` AS category";
    $join_clause = "JOIN categories ON tickets.`" . $tickets_fk . "` = categories.`" . $categories_pk . "`";
} elseif ($tickets_fk) {
    $category_select = "tickets.`" . $tickets_fk . "` AS category_id";
    $join_clause = "";
} else {
    $category_select = "NULL AS category";
    $join_clause = "";
}

$query_tickets = "\n    SELECT tickets.id, $category_select, tickets.description, tickets.status, tickets.created_at\n    FROM tickets\n    $join_clause\n    WHERE tickets.user_id = ?\n";

if ($filter_option !== 'all') {
    $query_tickets .= " AND tickets.status = ?";
}
$query_tickets .= " ORDER BY tickets.created_at DESC";

// Prepare the new statement
$stmt_tickets = $conn->prepare($query_tickets);


if ($filter_option === 'all') {
    $stmt_tickets->bind_param("i", $_SESSION['user_id']);
} else {
    $stmt_tickets->bind_param("is", $_SESSION['user_id'], $filter_option);
}

// Execute the query
if (!$stmt_tickets->execute()) {
    die("Error fetching tickets: " . $stmt_tickets->error);
}
$result_tickets = $stmt_tickets->get_result();

// Fetch categories dynamically for the form and build a map for display
$categories_map = [];
if ($category_display_column) {
    $query_categories = "SELECT id, `" . $category_display_column . "` AS display_name FROM categories";
    if ($result_categories = $conn->query($query_categories)) {
        while ($row = $result_categories->fetch_assoc()) {
            $categories_map[$row['id']] = $row['display_name'];
        }
        // reset pointer for the form select (we'll re-query for iteration below)
        $result_categories->data_seek(0);
    } else {
        // Non-fatal: keep categories_map empty and let the form handle no-categories
        error_log("Error fetching categories: " . $conn->error);
    }
} else {
    // Try to at least fetch ids so the form has options (will show ids as labels)
    $query_categories = "SELECT id FROM categories";
    if ($result_categories = $conn->query($query_categories)) {
        while ($row = $result_categories->fetch_assoc()) {
            $categories_map[$row['id']] = $row['id'];
        }
        $result_categories->data_seek(0);
    } else {
        error_log("Error fetching categories: " . $conn->error);
    }
}
?>

<link rel="stylesheet" href="css/dashboard.css">
<!DOCTYPE html>
<html lang="en">
<div class="dashboard-header">
    <h1>Welcome, <?= htmlspecialchars($_SESSION['name']); ?>!</h1>
    <a href="logout.php" class="btn-logout">Logout</a>
</div>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
</head>
<body>

<!-- Filter Options -->
<form action="dashboard.php" method="GET" style="max-width: 600px; margin: auto;">
    <label for="filter">Filter Tickets By Status:</label>
    <select id="filter" name="filter" onchange="this.form.submit()">
        <option value="all" <?= $filter_option === 'all' ? 'selected' : '' ?>>Show All</option>
        <option value="Pending" <?= $filter_option === 'Pending' ? 'selected' : '' ?>>Pending</option>
        <option value="In Progress" <?= $filter_option === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
        <option value="Resolved" <?= $filter_option === 'Resolved' ? 'selected' : '' ?>>Resolved</option>
    </select>
</form>

<!-- Show All Tickets -->
<h2 style="text-align: center;">Filtered Tickets</h2>
<table class="dashboard-table">
    <thead>
        <tr>
            <th>Category</th>
            <th>Description</th>
            <th>Status</th>
            <th>Submitted At</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result_tickets->num_rows > 0): ?>
            <?php foreach ($result_tickets as $ticket): ?>
                <tr>
                    <td>
                        <?php
                        // Prefer 'category' field from the query if present, otherwise map category_id
                        if (isset($ticket['category'])) {
                            echo htmlspecialchars($ticket['category']);
                        } elseif (isset($ticket['category_id'])) {
                            $cid = $ticket['category_id'];
                            echo htmlspecialchars(isset($categories_map[$cid]) ? $categories_map[$cid] : $cid);
                        } else {
                            echo 'N/A';
                        }
                        ?>
                    </td>
                    <td><?= htmlspecialchars($ticket['description']); ?></td>
                    <td><?= htmlspecialchars($ticket['status']); ?></td>
                    <td><?= htmlspecialchars($ticket['created_at']); ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" style="text-align: center;">No tickets found for the selected filter.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Submit Issue Form -->
<h2>Submit a New Issue</h2>
<form action="submit_issue.php" method="POST" style="max-width: 600px; margin: auto;">
    <!-- Category Selection -->
    <label for="category">Category:</label>
    <select id="category" name="category" required>
        <?php if (isset($result_categories) && $result_categories->num_rows > 0): ?>
            <?php while ($category = $result_categories->fetch_assoc()): ?>
                <?php
                $label = $category['id'];
                if (isset($category['display_name'])) {
                    $label = $category['display_name'];
                } elseif (isset($categories_map[$category['id']])) {
                    $label = $categories_map[$category['id']];
                }
                ?>
                <option value="<?= $category['id']; ?>"><?= htmlspecialchars($label); ?></option>
            <?php endwhile; ?>
        <?php else: ?>
            <option value="">No categories available</option>
        <?php endif; ?>
    </select>
    <!-- Description Textarea -->
    <label for="description">Description:</label>
    <textarea id="description" name="description" placeholder="Describe your issue" rows="5" required></textarea>

    <!-- Submit Button -->
    <button type="submit">Submit Issue</button>
</form>
</body>
</html>

<?php
include 'includes/footer.html'; // Include footer
$stmt_tickets->close();
$conn->close();
?>
