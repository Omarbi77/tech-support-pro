<?php
// Quick test to validate ticket query build logic from dashboard.php
session_start();
include 'includes/db.php';
$dbname = isset($dbname) ? $dbname : 'tech_support_db';
// Copy relevant detection logic from dashboard.php
$category_display_column = null;
$col_check_sql = "SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'categories' ORDER BY ORDINAL_POSITION";
if ($stmt_col = $conn->prepare($col_check_sql)) {
    $stmt_col->bind_param("s", $dbname);
    $stmt_col->execute();
    $res = $stmt_col->get_result();
    while ($col = $res->fetch_assoc()) {
        if ($col['COLUMN_NAME'] === 'category_name') {
            $category_display_column = 'category_name';
            break;
        }
        if ($category_display_column === null && $col['COLUMN_NAME'] !== 'id' && in_array(strtolower($col['DATA_TYPE']), ['varchar','text','char','tinytext','mediumtext','longtext'])) {
            $category_display_column = $col['COLUMN_NAME'];
        }
    }
    $stmt_col->close();
}
// Detect tickets foreign-key column
$tickets_fk = null;
$tickets_cols_sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'tickets' ORDER BY ORDINAL_POSITION";
if ($stmt_tc = $conn->prepare($tickets_cols_sql)) {
    $stmt_tc->bind_param("s", $dbname);
    $stmt_tc->execute();
    $res_tc = $stmt_tc->get_result();
    $preferred = ['category_id','categoryid','category','cat_id','catid'];
    while ($c = $res_tc->fetch_assoc()) {
        $colname = $c['COLUMN_NAME'];
        foreach ($preferred as $p) {
            if (strcasecmp($colname, $p) === 0) {
                $tickets_fk = $colname;
                break 2;
            }
        }
        if ($tickets_fk === null && (stripos($colname, 'category') !== false || stripos($colname, 'cat') !== false)) {
            $tickets_fk = $colname;
        }
    }
    $stmt_tc->close();
}
// Find categories PK
$categories_pk = 'id';
$pk_sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'categories' AND COLUMN_KEY = 'PRI' LIMIT 1";
if ($stmt_pk = $conn->prepare($pk_sql)) {
    $stmt_pk->bind_param("s", $dbname);
    $stmt_pk->execute();
    $res_pk = $stmt_pk->get_result();
    if ($rowpk = $res_pk->fetch_assoc()) {
        $categories_pk = $rowpk['COLUMN_NAME'];
    }
    $stmt_pk->close();
}
$join_clause = '';
if ($tickets_fk && $categories_pk) {
    $join_clause = "JOIN categories ON tickets.`" . $tickets_fk . "` = categories.`" . $categories_pk . "`";
}
if ($category_display_column && $join_clause !== '') {
    $category_select = "categories.`" . $category_display_column . "` AS category";
} elseif ($tickets_fk) {
    $category_select = "tickets.`" . $tickets_fk . "` AS category_id";
} else {
    $category_select = "NULL AS category";
}
$query_tickets = "\n    SELECT tickets.id, $category_select, tickets.description, tickets.status, tickets.created_at\n    FROM tickets\n    $join_clause\n    WHERE tickets.user_id = ?\n";

echo "Detected: category_display_column=" . var_export($category_display_column, true) . "\n";
echo "Detected: tickets_fk=" . var_export($tickets_fk, true) . "\n";
echo "Detected: categories_pk=" . var_export($categories_pk, true) . "\n";
echo "Constructed query:\n" . $query_tickets . "\n";

$stmt = $conn->prepare($query_tickets);
if (!$stmt) {
    echo "Prepare failed: " . $conn->error . "\n";
} else {
    echo "Prepare successful\n";
    $uid = 1;
    $stmt->bind_param('i', $uid);
    if (!$stmt->execute()) {
        echo "Execute failed: " . $stmt->error . "\n";
    } else {
        $res = $stmt->get_result();
        echo "Rows: " . ($res ? $res->num_rows : 'n/a') . "\n";
    }
}

$conn->close();

?>