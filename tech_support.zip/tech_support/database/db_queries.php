<?php
function getMessageById($conn, $id) {
    $query = "SELECT * FROM contact_messages WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function saveReply($conn, $messageId, $adminId, $reply) {
    $query = "INSERT INTO contact_replies (message_id, admin_id, reply) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iis", $messageId, $adminId, $reply);
    return $stmt->execute();
}
?>
