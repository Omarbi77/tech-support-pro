<?php
// Database connection configuration
$host = 'localhost'; // Database host
$user = 'root'; // Database username
$password = ''; // Database password (leave blank for default XAMPP configuration)
$dbname = 'tech_support_db'; // Database name


// Create a new connection to the database
$conn = new mysqli($host, $user, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

echo 'Database connection successful!';
?>
