-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY, -- Unique identifier for each user
    name VARCHAR(100) NOT NULL, -- Full name of the user
    email VARCHAR(100) UNIQUE NOT NULL, -- Unique email for login and communication
    password VARCHAR(255) NOT NULL, -- Hashed password for security
    phone VARCHAR(15), -- Optional phone number
    role ENUM('user', 'admin') DEFAULT 'user', -- Role defines user or admin access
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Timestamp for account creation
);

-- Services table
CREATE TABLE services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(100),
    description TEXT,
    price DECIMAL(10, 2)
);
-- Ticket categories table for normalization
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY, -- Unique identifier for each category
    category_name VARCHAR(50) NOT NULL -- Name of the ticket category
);

-- Tickets table
CREATE TABLE tickets (
    id INT AUTO_INCREMENT PRIMARY KEY, -- Unique identifier for each ticket
    user_id INT NOT NULL, -- Foreign key linking to the user who created the ticket
    category_id INT NOT NULL, -- Foreign key linking to the ticket category
    description TEXT, -- Detailed description of the issue
    status ENUM('Pending', 'In Progress', 'Resolved', 'Closed') DEFAULT 'Pending', -- Current status of the ticket
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Timestamp for ticket creation
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, -- Cascade delete for user-related tickets
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE -- Cascade delete for category-related tickets
);

-- Feedback table
CREATE TABLE feedback (
    id INT AUTO_INCREMENT PRIMARY KEY, -- Unique identifier for each feedback
    user_id INT NOT NULL, -- Foreign key linking to the user providing feedback
    feedback TEXT NOT NULL, -- Textual feedback provided by the user
    rating INT CHECK (rating BETWEEN 1 AND 5), -- Rating between 1 (low) and 5 (high)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Timestamp for feedback submission
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE -- Cascade delete for user-related feedback
);

-- Blog table
CREATE TABLE blogs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- Admin logs table for audit purposes
CREATE TABLE admin_logs (
    id INT AUTO_INCREMENT PRIMARY KEY, -- Unique identifier for each log entry
    admin_id INT NOT NULL, -- Foreign key linking to the admin performing the action
    action TEXT NOT NULL, -- Description of the action performed
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Timestamp for the logged action
    FOREIGN KEY (admin_id) REFERENCES users(id) -- Links to users table where role is 'admin'
);
-- Indexes for optimization
CREATE INDEX idx_users_email ON users(email); -- Index on email for quick lookups
CREATE INDEX idx_tickets_created_at ON tickets(created_at); -- Index on ticket creation date for faster queries

-- Sample data
INSERT INTO services (service_name, description, price)
VALUES
('Laptop Repair', 'Fix hardware and software issues.', 50.00),
('Network Setup', 'Configure your home or office network.', 75.00),
('Data Recovery', 'Recover lost or corrupted data.', 100.00);
