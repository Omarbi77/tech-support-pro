-- Migration: create contact_replies table
CREATE TABLE IF NOT EXISTS contact_replies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    message_id INT NOT NULL,
    admin_id INT DEFAULT NULL,
    reply TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_message_id (message_id),
    CONSTRAINT fk_contact_replies_message FOREIGN KEY (message_id) REFERENCES contact_messages(id) ON DELETE CASCADE,
    CONSTRAINT fk_contact_replies_admin FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE SET NULL
);
