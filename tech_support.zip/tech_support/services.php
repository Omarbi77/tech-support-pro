<?php 
include 'includes/header.html'; // Include the header of the page
?>
<link rel="stylesheet" href="css/services.css">
<!-- Hero Section with Background Image -->
<div class="services-hero">
    <div class="services-hero-content">
        <h1>Our Services</h1> <!-- Heading for the services page -->
        <p>Explore our wide range of IT solutions designed to fit your needs.</p> <!-- Description under the heading -->
    </div>
</div>

<!-- Services Section -->
<div class="services">
    <?php
    include 'includes/db.php'; // Include the database connection file
    $query = "SELECT * FROM services"; // Query to fetch all services from the database
    $result = $conn->query($query); // Execute the query

    if ($result->num_rows > 0) { // Check if there are any services in the database
        while ($row = $result->fetch_assoc()) { // Loop through each service
            // Default icon selection based on the service name
            $icon = ""; 
            switch ($row['service_name']) {
                case 'Laptop Repair':
                    $icon = 'icon-laptop.png'; // Laptop Repair icon
                    break;
                case 'Network Setup':
                    $icon = 'icon-network.png'; // Network Setup icon
                    break;
                case 'Data Recovery':
                    $icon = 'icon-data-recovery.png'; // Data Recovery icon
                    break;
                case 'IT Consultation':
                    $icon = 'icon-consultation.png'; // IT Consultation icon
                    break;
                default:
                    $icon = 'icon-default.png'; // Fallback icon for services that don't match the above
            }

            // Display the service item with its icon, name, description, and price
            echo "<div class='service-item'>";
            echo "<img src='css/images/" . $icon . "' alt='" . htmlspecialchars($row['service_name']) . " Icon'>"; // Icon for the service
            echo "<h2>" . htmlspecialchars($row['service_name']) . "</h2>"; // Service name
            echo "<p>" . htmlspecialchars($row['description']) . "</p>"; // Service description
            echo "<p>Price: $" . htmlspecialchars($row['price']) . "</p>"; // Service price
            echo "</div>";
        }
    } else {
        echo "<p>No services available at the moment.</p>"; // Message if no services are found
    }
    ?>
</div>

<?php 
include 'includes/footer.html'; // Include the footer of the page
?>
