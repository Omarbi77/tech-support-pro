<?php 
// Include the reusable header file, so the header section is included at the top of the page
include 'includes/header.html'; 
?>
<link rel="stylesheet" href="css/about.css">

<!-- Hero Section: Introduces the page -->
<div class="about-hero">
    <div class="about-hero-content">
        <h1>About Us</h1> <!-- Main heading for the page -->
        <p>Your trusted partner in reliable IT solutions and exceptional customer service.</p> <!-- Subheading to describe the business -->
    </div>
</div>

<!-- Values Section: Highlights company values -->
<div class="values">
    <h2>Our Values</h2> <!-- Heading for the values section -->
    <div class="values-list">
        <!-- Value 1: Reliable Service -->
        <div class="value-item">
            <img src="css/images/icon-reliable.png" alt="Reliable Service Icon"> <!-- Icon representing reliable service -->
            <h3>Reliable Service</h3> <!-- Heading for the first value -->
            <p>We provide consistent and dependable IT support tailored to your unique needs.</p> <!-- Description of the first value -->
        </div>

        <!-- Value 2: Experienced Team -->
        <div class="value-item">
            <img src="css/images/icon-experience.png" alt="Experienced Team Icon"> <!-- Icon representing experienced team -->
            <h3>Experienced Team</h3> <!-- Heading for the second value -->
            <p>Our team of skilled professionals is ready to handle any challenge you face.</p> <!-- Description of the second value -->
        </div>

        <!-- Value 3: Customer First -->
        <div class="value-item">
            <img src="css/images/icon-customer.png" alt="Customer First Icon"> <!-- Icon representing customer-first approach -->
            <h3>Customer First</h3> <!-- Heading for the third value -->
            <p>We prioritize customer satisfaction in every service we deliver.</p> <!-- Description of the third value -->
        </div>
    </div>
</div>

<?php 
// Include the reusable footer file, so the footer section is included at the bottom of the page
include 'includes/footer.html'; 
?>
