<?php
session_start();
include 'includes/db.php'; // Include database connection
include 'includes/schema.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$successMessage = $errorMessage = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $category_id = intval($_POST['category']); // Expect category_id
    $description = htmlspecialchars(trim($_POST['description']));

    // Validate inputs
    if ($category_id > 0 && !empty($description)) {
        // Ensure the category_id exists in the categories table
        $category_check_query = "SELECT id FROM categories WHERE id = ?";
        $category_check_stmt = $conn->prepare($category_check_query);
        $category_check_stmt->bind_param("i", $category_id);
        $category_check_stmt->execute();
        $category_check_result = $category_check_stmt->get_result();

        if ($category_check_result->num_rows > 0) {
            // Insert the ticket
            // Detect tickets foreign-key column (e.g., category, category_id, etc.)
            $tickets_fk = 'category_id';
            $tickets_cols_sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'tickets' ORDER BY ORDINAL_POSITION";
            if ($stmt_tc = $conn->prepare($tickets_cols_sql)) {
                $stmt_tc->bind_param("s", $dbname);
                $stmt_tc->execute();
                $res_tc = $stmt_tc->get_result();
                $preferred = ['category_id','categoryid','category','cat_id','catid'];
                while ($c = $res_tc->fetch_assoc()) {
                    $colname = $c['COLUMN_NAME'];
                    foreach ($preferred as $p) {
                        if (strcasecmp($colname, $p) === 0) {
                            $tickets_fk = $colname;
                            break 2;
                        }
                    }
                    if ($tickets_fk === 'category_id' && (stripos($colname, 'category') !== false || stripos($colname, 'cat') !== false)) {
                        $tickets_fk = $colname;
                    }
                }
                $stmt_tc->close();
            }

            $query = "INSERT INTO tickets (user_id, `" . $tickets_fk . "`, description, status) VALUES (?, ?, ?, 'Pending')";
            $stmt = $conn->prepare($query);
            if ($stmt) {
                $stmt->bind_param("iis", $user_id, $category_id, $description);
                if ($stmt->execute()) {
                    $successMessage = "Issue submitted successfully!";
                } else {
                    $errorMessage = "Error submitting issue: " . htmlspecialchars($stmt->error);
                }
            } else {
                $errorMessage = "Error preparing statement: " . htmlspecialchars($conn->error);
            }
        } else {
            $errorMessage = "Invalid category selected.";
        }
    } else {
        $errorMessage = "Please fill in all fields.";
    }
}

// Redirect to the dashboard with messages
if (!empty($successMessage) || !empty($errorMessage)) {
    $params = [];
    if (!empty($successMessage)) {
        $params['success'] = $successMessage;
    }
    if (!empty($errorMessage)) {
        $params['error'] = $errorMessage;
    }
    header("Location: dashboard.php?" . http_build_query($params));
    exit();
}

// Default redirection
header("Location: dashboard.php");
exit();
?>
