<?php
// Start the session
session_start();
include 'includes/header.html'; // Include header
include 'includes/db.php'; // Include database connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

$user_id = $_SESSION['user_id']; // Retrieve the user ID from session

// Fetch current user data
$query = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc(); // Get user data as an associative array

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars($_POST['name']); // Sanitize input
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);

    // Update the user's profile in the database
    $update_query = "UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("sssi", $name, $email, $phone, $user_id);

    if ($update_stmt->execute()) {
        $successMessage = "Profile updated successfully!";
    } else {
        $errorMessage = "Error: " . $update_stmt->error;
    }
}
?>
<link rel="stylesheet" href="css/profile.css">


<!-- Hero Section -->
<div class="profile-hero">
    <h1>Welcome, <?php echo htmlspecialchars($user['name']); ?>!</h1>
    <p>Manage your account details below.</p>
    <a href="logout.php" class="btn btn-logout">Logout</a> <!-- Logout Button -->
</div>

<!-- Profile Form Section -->
<div class="profile-container">
    <!-- Display success or error messages -->
    <?php if (isset($successMessage)): ?>
        <p class="success-message"><?php echo htmlspecialchars($successMessage); ?></p>
    <?php elseif (isset($errorMessage)): ?>
        <p class="error-message"><?php echo htmlspecialchars($errorMessage); ?></p>
    <?php endif; ?>

    <!-- Profile Update Form -->
    <form action="" method="POST" class="profile-form">
        <div class="form-group">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        </div>

        <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
        </div>

        <button type="submit" class="btn">Update Profile</button>
    </form>
</div>
 
        <!-- Return to Dashboard Button -->
        <a href="<?= $user['role'] === 'admin' ? 'admin.php' : 'dashboard.php'; ?>" class="btn-back">
            Return to Dashboard
        </a>
    </div>
</body>
</html>

<?php include 'includes/footer.html'; // Include footer ?>
