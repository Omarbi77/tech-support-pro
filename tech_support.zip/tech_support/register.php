<?php
include 'includes/header.html';
include 'includes/db.php';

// Handle registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);
    $confirm_password = htmlspecialchars($_POST['confirm_password']);

    $errorMessage = null;
    $successMessage = null;

    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        $errorMessage = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $errorMessage = "Passwords do not match.";
    } else {
        $query = "SELECT id FROM users WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $errorMessage = "Email is already registered.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $query = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt = $conn->prepare($query);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

            $stmt->bind_param("sss", $name, $email, $hashed_password);

            if ($stmt->execute()) {
                $successMessage = "Registration successful! You can now log in.";
            } else {
                $errorMessage = "Error registering user: " . $conn->error;
            }
        }
    }
}
?>
<img src="css/images/register-hero-bg.jpg" alt="Background">
<link rel="stylesheet" href="css/register.css">

<div class="register-container">
    <h1>Register</h1>
    <p>Create an account to enjoy our services.</p>

    <?php if (isset($errorMessage)): ?>
        <p class="error-message"><?= htmlspecialchars($errorMessage); ?></p>
    <?php endif; ?>
    <?php if (isset($successMessage)): ?>
        <p class="success-message"><?= htmlspecialchars($successMessage); ?></p>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <button type="submit">Register</button>
    </form>

    <p>Already have an account? <a href="login.php" class="login-link">Log in here</a></p>
</div>

<?php include 'includes/footer.html'; ?>
